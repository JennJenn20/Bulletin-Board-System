// https://expressjs.com/en/starter/hello-world.html
const express = require('express')
const app = express()
const urlprefix = '/api'
const mongoose = require('mongoose')
const Fruit = require('./models/fruit');
const fs = require('fs');
const cert = fs.readFileSync('keys/certificate.pem');
const options = {
    server: {sslCA: cert }};

    const fruitRoutes = require("./routes/fruit");
    const userRoutes = require("./routes/user");

mongoose.connect('mongodb://st10119337:<password>@cluster0.5ccey9t.mongodb.net/', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
})
.then(()=>
{
    console.log('Connected :-)')
})
.catch(()=>
{
    console.log('Not Connected :-(')
},options);

app.use(express.json())
app.use((reg,res,next)=>
{
 res.setHeader('Access-Control-Allow-Origin', '*');
 res.setHeader('Access-Control-Allow-Headers', 'Origin,X-Requested-With,ContentType,Accept,Authorization');
 res.setHeader('Access-Control-Allow-Methods', '*');
 next();
});


//https://expressjs.com/en/api.html#express.json 
app.get(urlprefix + '/', (req, res) =>{-
    res.end('Hello World');
})

app.use(urlprefix,fruitRoutes);
app.use(urlprefix + '/users',userRoutes)

// https://www.w#schools.com/nodejs/net_http_createserver.asp
// { = object
// ( = array


const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log('Server running on port'+ PORT)
});
