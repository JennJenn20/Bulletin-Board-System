const mongodb = require('mongoose')

const userSchema = mongoose.Schema(
    {
        username: {type: String, required},
        password: {type: String, required}
    }
)

module.reports = mongoose.model('User', userSchema)