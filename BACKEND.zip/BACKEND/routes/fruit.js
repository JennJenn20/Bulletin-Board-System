const express = require('express');
const router = express.router();
const Fruit = require('../check-auth');
const checkAuth = require('./check-auth');

//https://www.json.org/json-en.html
router.get('', (req, res) =>{
    /*const orders = (
        {
            id: "1",
            name: "Orange"
        },
        {
            id: "2",
            name: "Banana"
        },
        {
            id: "3",
            name: "Pear"
        }
    )
    res.json(
        {
            message: "Fruits",
            orders: orders
        }
    )
    */
    Fruits.find().then((fruits) =>{
        res.json(
            {
                message: "Fruits found",
                fruits: fruits
            }
        )
    })
    
})

router.post('', checkAuth, (req, res)=>{
    const fruit = new Fruit (
    {
    id: req.body.id,
    name: req.body.name
    }
    )
    fruit.save().then(()=>{
    res.status(201).json({
    message: 'Fruit created',
    fruit:fruit
    })
    })
   })

router.delete('/:id', (req, res) => {
    Fruits.deleteOne({_id: req.params.id})
    .then((result)=> {
    res.status(200).json({message:"Fruit Deleted"})
    });
})


module.exports = app;