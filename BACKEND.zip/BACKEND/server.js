// https://www.w#schools.com/nodejs/nodejs_modules.asp 
const http = require('http');
const app = require('./app');
const fs = require('fs');

const PORT = process.env.PORT || 3000;

// https://www.w#schools.com/nodejs/net_http_createserver.asp
const server = http.createServer({
    key: fs.readFileSync('keys/privatekey'),
    cert : fs.readFileSync('keys/certificate'),
})

server.listen(PORT)

app.listen(PORT, ()=> {
    console.log('Server running on port'+ PORT)
});